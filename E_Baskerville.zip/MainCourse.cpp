#include "MainCourse.h"

MainCourse::MainCourse(std::string name, float price, int calories)
{
	this->name = name;
	this->price = price;
	this->calories = calories;
}
